// import { REGISTER_SUCCESS, REGISTER_FAILURE } from '../actions/userActions';

// const initialState = {
//   success: false,
//   error: null,
// };

// const userReducer = (state = initialState, action) => {
//   switch (action.type) {
//     case REGISTER_SUCCESS:
//       return {
//         ...state,
//         success: true,
//         error: null,
//       };
//     case REGISTER_FAILURE:
//       return {
//         ...state,
//         success: false,
//         error: action.payload,
//       };
//     default:
//       return state;
//   }
// };

// export default userReducer;
